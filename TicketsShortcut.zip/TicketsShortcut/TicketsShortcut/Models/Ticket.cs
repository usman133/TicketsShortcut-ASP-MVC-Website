﻿using System;
using System.Collections.Generic;

namespace TicketsShortcut.Models
{
    public partial class Ticket
    {
        public int TicketId { get; set; }
        public int StoreId { get; set; }
        public int EventId { get; set; }
        public int CustomerId { get; set; }
        public decimal? Price { get; set; }
        public int Quantity { get; set; }
        public decimal? Total { get; set; }
        public DateTime PurchaseDate { get; set; }

        public Customer Customer { get; set; }
        public Event Event { get; set; }
        public Store Store { get; set; }
    }
}
