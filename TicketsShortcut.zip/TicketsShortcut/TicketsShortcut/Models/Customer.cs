﻿using System;
using System.Collections.Generic;

namespace TicketsShortcut.Models
{
    public partial class Customer
    {
        public Customer()
        {
            Ticket = new HashSet<Ticket>();
        }

        public int CustomerId { get; set; }
        public string Fname { get; set; }
        public string Lname { get; set; }
        public string Email { get; set; }
        public int Phone { get; set; }
        public string Address { get; set; }

        public ICollection<Ticket> Ticket { get; set; }
    }
}
