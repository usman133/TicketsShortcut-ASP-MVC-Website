﻿using System;
using System.Collections.Generic;

namespace TicketsShortcut.Models
{
    public partial class Staff
    {
        public int StaffId { get; set; }
        public int StoreId { get; set; }
        public string Fname { get; set; }
        public string Lname { get; set; }
        public string Role { get; set; }
        public int Phone { get; set; }
        public string Email { get; set; }
        public string Address { get; set; }

        public Store Store { get; set; }
    }
}
