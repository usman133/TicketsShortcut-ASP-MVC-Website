﻿using System;
using System.Collections.Generic;

namespace TicketsShortcut.Models
{
    public partial class Store
    {
        public Store()
        {
            Event = new HashSet<Event>();
            Staff = new HashSet<Staff>();
            Ticket = new HashSet<Ticket>();
        }

        public int StoreId { get; set; }
        public string Name { get; set; }
        public string Website { get; set; }
        public int Phone { get; set; }
        public string Email { get; set; }
        public string Location { get; set; }

        public ICollection<Event> Event { get; set; }
        public ICollection<Staff> Staff { get; set; }
        public ICollection<Ticket> Ticket { get; set; }
    }
}
