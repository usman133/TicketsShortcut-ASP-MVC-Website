﻿using System;
using System.Collections.Generic;

namespace TicketsShortcut.Models
{
    public partial class Venue
    {
        public Venue()
        {
            Event = new HashSet<Event>();
        }

        public int VenueId { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public int Phone { get; set; }
        public string Email { get; set; }
        public int? Capacity { get; set; }

        public ICollection<Event> Event { get; set; }
    }
}
