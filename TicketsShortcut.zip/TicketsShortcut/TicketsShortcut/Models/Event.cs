﻿using System;
using System.Collections.Generic;

namespace TicketsShortcut.Models
{
    public partial class Event
    {
        public Event()
        {
            Ticket = new HashSet<Ticket>();
        }

        public int EventId { get; set; }
        public int VenueId { get; set; }
        public int StoreId { get; set; }
        public string Name { get; set; }
        public string Sport { get; set; }
        public string Teams { get; set; }
        public DateTime Date { get; set; }
        public string Duration { get; set; }
        public decimal? Price { get; set; }
        public int? AvailableSeats { get; set; }

        public Store Store { get; set; }
        public Venue Venue { get; set; }
        public ICollection<Ticket> Ticket { get; set; }
    }

}
